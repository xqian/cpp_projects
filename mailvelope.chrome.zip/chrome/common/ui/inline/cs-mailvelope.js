
/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var mvelo = mvelo || {};
// chrome extension
mvelo.crx = typeof chrome !== 'undefined';
// firefox addon
mvelo.ffa = mvelo.ffa || typeof self !== 'undefined' && self.port || !mvelo.crx;
// for fixfox, mvelo.extension is exposed from a content script
mvelo.extension = mvelo.extension || mvelo.crx && chrome.runtime;
// for fixfox, mvelo.l10n is exposed from a content script
mvelo.l10n = mvelo.l10n || mvelo.crx && {
  getMessages: function(ids, callback) {
    var result = {};
    ids.forEach(function(id) {
      result[id] = chrome.i18n.getMessage(id);
    });
    callback(result);
  },
  localizeHTML: function(l10n) {
    $('[data-l10n-id]').each(function() {
      var jqElement = $(this);
      var id = jqElement.data('l10n-id');
      var text = l10n ? l10n[id] : chrome.i18n.getMessage(id);
      jqElement.text(text);
    });
  }
};
// min height for large frame
mvelo.LARGE_FRAME = 600;
// frame constants
mvelo.FRAME_STATUS = 'stat';
// frame status
mvelo.FRAME_ATTACHED = 'att';
mvelo.FRAME_DETACHED = 'det';
// key for reference to frame object
mvelo.FRAME_OBJ = 'fra';
// marker for dynamically created iframes
mvelo.DYN_IFRAME = 'dyn';
mvelo.IFRAME_OBJ = 'obj';
// armor header type
mvelo.PGP_MESSAGE = 'msg';
mvelo.PGP_SIGNATURE = 'sig';
mvelo.PGP_PUBLIC_KEY = 'pub';
mvelo.PGP_PRIVATE_KEY = 'priv';
// editor mode
mvelo.EDITOR_WEBMAIL = 'webmail';
mvelo.EDITOR_EXTERNAL = 'external';
mvelo.EDITOR_BOTH = 'both';
// display decrypted message
mvelo.DISPLAY_INLINE = 'inline';
mvelo.DISPLAY_POPUP = 'popup';
// editor type
mvelo.PLAIN_TEXT = 'plain';
mvelo.RICH_TEXT = 'rich';

// random hash generator
mvelo.getHash = function() { return Math.random().toString(36).substr(2, 8); };

mvelo.encodeHTML = function(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
    .replace(/\//g, "&#x2F;");
};

if (typeof exports !== 'undefined') {
  exports.mvelo = mvelo;
}

/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

(function() {
  if (document.mveloControl) return;

  var interval = 2500; // ms
  var intervalID = 0;
  var regex = /END\sPGP/;
  var minEditHeight = 84;
  var contextTarget = null;
  var prefs = null;
  var name = 'mainCS-' + mvelo.getHash();
  var port = null;

  function init() {
    port = mvelo.extension.connect({name: name});
    addMessageListener();
    port.postMessage({event: 'get-prefs', sender: name});
    //initContextMenu();
  }

  function on() {
    //console.log('inside cs: ', document.location.host);
    if (intervalID === 0) {
      intervalID = window.setInterval(scanLoop, interval);
    }
  }

  function off() {
    if (intervalID !== 0) {
      window.clearInterval(intervalID);
      intervalID = 0;
    }
  }

  function scanLoop() {
    // find editable content
    var editable = findEditable();
    if (editable.length !== 0) {
      attachEncryptFrame(editable);
    }
  }

  /**
   * find text nodes in DOM that match certain pattern
   * @param regex
   * @return $([nodes])
   */
  function findPGPTag(regex) {
    var treeWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: function(node) {
        if (node.parentNode.tagName !== 'SCRIPT' && regex.test(node.textContent)) {
          return NodeFilter.FILTER_ACCEPT;
        } else {
          return NodeFilter.FILTER_REJECT;
        }
      }
    }, false);

    var nodeList = [];

    while (treeWalker.nextNode()) nodeList.push(treeWalker.currentNode);

    // filter out hidden elements
    nodeList = $(nodeList).filter(function() {
      var element = $(this);
      // visibility check does not work on text nodes
      return element.parent().is(':visible') &&
        // no elements within editable elements
        element.parents('[contenteditable], textarea').length === 0 &&
        this.ownerDocument.designMode !== 'on';
    });

    return nodeList;
  }

  function findEditable() {
    // find textareas and elements with contenteditable attribute, filter out <body>
    var editable = $('[contenteditable], textarea').filter(':visible').not('body');
    var iframes = $('iframe').filter(':visible');
    // find dynamically created iframes where src is not set
    var dynFrames = iframes.filter(function() {
      var src = $(this).attr('src');
      return src === undefined ||
             src === '' ||
             /^javascript.*/.test(src) ||
             /^about.*/.test(src);
    });
    // find editable elements inside dynamic iframe (content script is not injected here)
    dynFrames.each(function() {
      var content = $(this).contents();
      // set event handler for contextmenu
      content.find('body').off("contextmenu").on("contextmenu", onContextMenu)
      // mark body as 'inside iframe'
                          .data(mvelo.DYN_IFRAME, true)
      // add iframe element
                          .data(mvelo.IFRAME_OBJ, $(this));
      // document of iframe in design mode or contenteditable set on the body
      if (content.attr('designMode') === 'on' || content.find('body[contenteditable]').length !== 0) {
        // add iframe to editable elements
        editable = editable.add($(this));
      } else {
        // editable elements inside iframe
        var editblElem = content.find('[contenteditable], textarea').filter(':visible');
        editable = editable.add(editblElem);
      }
    });
    // find iframes from same origin with a contenteditable body (content script is injected, but encrypt frame needs to be attached to outer iframe)
    var anchor = $('<a/>');
    var editableBody = iframes.not(dynFrames).filter(function() {
      var frame = $(this);
      // only for iframes from same host
      if (anchor.attr('href', frame.attr('src')).prop('hostname') === document.location.hostname) {
        try {
          var content = frame.contents();
          if (content.attr('designMode') === 'on' || content.find('body[contenteditable]').length !== 0) {
            // set event handler for contextmenu
            content.find('body').off("contextmenu").on("contextmenu", onContextMenu);
            // mark body as 'inside iframe'
            content.find('body').data(mvelo.IFRAME_OBJ, frame);
            return true;
          } else {
            return false;
          }
        } catch (e) {
          return false;
        }
      }
    });
    editable = editable.add(editableBody);
    // filter out elements below a certain height limit
    editable = editable.filter(function() {
      return $(this).height() > minEditHeight;
    });
    return editable;
  }

  function getMessageType(pgpEnd) {
    var armored = pgpEnd.text();
    if (/END\sPGP\sMESSAGE/.test(armored)) {
      return mvelo.PGP_MESSAGE;
    } else if (/END\sPGP\sSIGNATURE/.test(armored)) {
      return mvelo.PGP_SIGNATURE;
    } else if (/END\sPGP\sPUBLIC\sKEY\sBLOCK/.test(armored)) {
      return mvelo.PGP_PUBLIC_KEY;
    } else if (/END\sPGP\sPRIVATE\sKEY\sBLOCK/.test(armored)) {
      return mvelo.PGP_PRIVATE_KEY;
    }
  }

  function attachExtractFrame(element) {
    // check status of PGP tags
    var newObj = element.filter(function() {
      return !ExtractFrame.isAttached($(this).parent());
    });
    // create new decrypt frames for new discovered PGP tags
    newObj.each(function(index, element) {
      // parent element of text node
      var pgpEnd = $(element).parent();
      switch (getMessageType(pgpEnd)) {
        case mvelo.PGP_MESSAGE:
          var dFrame = new DecryptFrame(prefs);
          dFrame.attachTo(pgpEnd);
          break;
        case mvelo.PGP_SIGNATURE:
          var vFrame = new VerifyFrame(prefs);
          vFrame.attachTo(pgpEnd);
          break;
        case mvelo.PGP_PUBLIC_KEY:
          var imFrame = new ImportFrame(prefs);
          imFrame.attachTo(pgpEnd);
          break;
      }
    });
  }

  /**
   * attach encrypt frame to element
   * @param  {$} element
   * @param  {boolean} expanded state of frame
   */
  function attachEncryptFrame(element, expanded) {
    // check status of elements
    var newObj = element.filter(function() {
      if (expanded) {
        // filter out only attached frames
        if (element.data(mvelo.FRAME_STATUS) === mvelo.FRAME_ATTACHED) {
          // trigger expand state of attached frames
          element.data(mvelo.FRAME_OBJ).showEncryptDialog();
          return false;
        } else {
          return true;
        }
      } else {
        // filter out attached and detached frames
        return !EncryptFrame.isAttached($(this));
      }
    });
    // create new encrypt frames for new discovered editable fields
    newObj.each(function(index, element) {
      var eFrame = new EncryptFrame(prefs);
      eFrame.attachTo($(element), {expanded: expanded});
    });
  }

  function addMessageListener() {
    port.onMessage.addListener(
      function(request) {
        //console.log('contentscript: %s onRequest: %o', document.location.toString(), request);
        if (request.event === undefined) return;
        switch (request.event) {
          case 'on':
            on();
            break;
          case 'off':
            off();
            break;
          case 'destroy':
            off();
            port.disconnect();
            break;
          case 'context-encrypt':
            if (contextTarget !== null) {
              attachEncryptFrame(contextTarget, true);
              contextTarget = null;
            }
            break;
          case 'set-prefs':
            prefs = request.prefs;
            if (prefs.main_active) {
              on();
            } else {
              off();
            }
            break;
          default:
            console.log('unknown event');
        }
      }
    );
  }

  function initContextMenu() {
    // set handler
    $("body").on("contextmenu", onContextMenu);
  }

  function onContextMenu(e) {
    //console.log(e.target);
    var target = $(e.target);
    // find editable descendants or ascendants
    var element = target.find('[contenteditable], textarea');
    if (element.length === 0) {
      element = target.closest('[contenteditable], textarea');
    }
    if (element.length !== 0 && !element.is('body')) {
      if (element.height() > minEditHeight) {
        contextTarget = element;
      } else {
        contextTarget = null;
      }
      return;
    }
    // inside dynamic iframe or iframes from same origin with a contenteditable body
    element = target.closest('body');
    // get outer iframe
    var iframeObj = element.data(mvelo.IFRAME_OBJ);
    if (iframeObj !== undefined) {
      // target set to outer iframe
      contextTarget = iframeObj;
      return;
    }
    // no suitable element found
    contextTarget = null;
  }

  document.mveloControl = true;
  init();

}());

/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2013  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var ExtractFrame = ExtractFrame || (function() {

  var extractFrame = function(prefs) {
    if (!prefs) {
      throw {
        message: 'ExtractFrame constructor: prefs not provided.'
      };
    }
    this.id = mvelo.getHash();
    // element with Armor Tail Line '-----END PGP...'
    this._pgpEnd = null;
    // element that contains complete ASCII Armored Message
    this._pgpElement = null;
    this._pgpElementAttr = {};
    this._eFrame = null;
    this._port = null;
    this._refreshPosIntervalID = null;
    this._pgpStartRegex = /BEGIN\sPGP/;
  };

  extractFrame.prototype = {

    attachTo: function(pgpEnd) {
      this._init(pgpEnd);
      this._renderFrame();
      this._establishConnection();
      this._registerEventListener();
    },

    _init: function(pgpEnd) {
      this._pgpEnd = pgpEnd;
      // find element with complete armored text and width > 0
      this._pgpElement = pgpEnd;
      while (!this._pgpStartRegex.test(this._pgpElement.text()) || this._pgpElement.width() <= 0) {
        this._pgpElement = this._pgpElement.parent();
      }
      // set status to attached
      this._pgpEnd.data(mvelo.FRAME_STATUS, mvelo.FRAME_ATTACHED);
      // store frame obj in pgpText tag
      this._pgpEnd.data(mvelo.FRAME_OBJ, this);

      this._pgpElementAttr.marginTop = parseInt(this._pgpElement.css('margin-top'), 10);
      this._pgpElementAttr.paddingTop = parseInt(this._pgpElement.css('padding-top'), 10);
    },

    _renderFrame: function() {
      this._eFrame = $('<div/>', {
        id: 'eFrame-' + this.id,
        'class': 'm-extract-frame m-cursor',
        html: '<a class="m-frame-close">×</a>'
      });

      this._setFrameDim();

      this._eFrame.insertAfter(this._pgpElement);
      if (this._pgpElement.height() > mvelo.LARGE_FRAME) {
        this._eFrame.addClass('m-large');
      }
      this._eFrame.fadeIn('slow');

      this._eFrame.on('click', this._clickHandler.bind(this));
      this._eFrame.find('.m-frame-close').on('click', this._closeFrame.bind(this));

      $(window).resize(this._setFrameDim.bind(this));
      this._refreshPosIntervalID = window.setInterval(this._setFrameDim.bind(this), 1000);
    },

    _clickHandler: function(callback) {
      this._eFrame.off('click');
      this._toggleIcon(callback);
      this._eFrame.removeClass('m-cursor');
      return false;
    },

    _closeFrame: function(finalClose) {
      this._eFrame.fadeOut(function() {
        window.clearInterval(this._refreshPosIntervalID);
        $(window).off('resize');
        this._eFrame.remove();
        if (finalClose === true) {
          this._port.disconnect();
          this._pgpEnd.data(mvelo.FRAME_STATUS, null);
        } else {
          this._pgpEnd.data(mvelo.FRAME_STATUS, mvelo.FRAME_DETACHED);
        }
        this._pgpEnd.data(mvelo.FRAME_OBJ, null);
      }.bind(this));
      return false;
    },

    _toggleIcon: function(callback) {
      this._eFrame.one('transitionend', callback);
      this._eFrame.toggleClass('m-open');
    },

    _setFrameDim: function() {
      var pgpElementPos = this._pgpElement.position();
      this._eFrame.width(this._pgpElement.width() - 2);
      this._eFrame.height(this._pgpEnd.position().top + this._pgpEnd.height() - pgpElementPos.top - 2);
      this._eFrame.css('top', pgpElementPos.top + this._pgpElementAttr.marginTop + this._pgpElementAttr.paddingTop);
    },

    _establishConnection: function() {
      this._port = mvelo.extension.connect({name: this._ctrlName});
      //console.log('Port connected: %o', this._port);
    },

    _htmlDecode: function(html) {
      return String(html)
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, "\"")
        .replace(/&#039;/g, "\'")
        .replace(/&#x2F;/g, "\/");
    },

    _getArmoredMessage: function() {
      var msg;
      if (this._pgpElement.is('pre')) {
        msg = this._pgpElement.clone();
        msg.find('br').replaceWith('\n');
        msg = msg.text();
      } else {
        msg = this._pgpElement.html();
        msg = msg.replace(/\n/g, ' '); // replace new line with space
        msg = msg.replace(/(<br>)/g, '\n'); // replace <br> with new line
        msg = msg.replace(/<\/(blockquote|div|dl|dt|dd|form|h1|h2|h3|h4|h5|h6|hr|ol|p|pre|table|tr|td|ul|li|section|header|footer)>/g, '\n'); // replace block closing tags </..> with new line
        msg = msg.replace(/<(.+?)>/g, ''); // remove tags
        msg = msg.replace(/&nbsp;/g, ' '); // replace non-breaking space with whitespace
        msg = this._htmlDecode(msg);
      }
      msg = msg.replace(/\n\s+/g, '\n'); // compress sequence of whitespace and new line characters to one new line
      msg = msg.match(this._typeRegex)[0];
      msg = msg.replace(/^(\s?>)+/gm, ''); // remove quotation
      msg = msg.replace(/^\s+/gm, ''); // remove leading whitespace
      msg = msg.replace(/:.*\n(?!.*:)/, '$&\n');  // insert new line after last armor header
      msg = msg.replace(/-----\n(?!.*:)/, '$&\n'); // insert new line if no header
      return msg;
    },

    _registerEventListener: function() {
      var that = this;
      this._port.onMessage.addListener(function(msg) {
        switch (msg.event) {
          case 'destroy':
            that._closeFrame(true);
            break;
        }
      });
    }

  };

  extractFrame.isAttached = function(pgpEnd) {
    var status = pgpEnd.data(mvelo.FRAME_STATUS);
    switch (status) {
      case mvelo.FRAME_ATTACHED:
      case mvelo.FRAME_DETACHED:
        return true;
      default:
        return false;
    }
  };

  return extractFrame;

}());

/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var DecryptFrame = DecryptFrame || (function() {

  var decryptFrame = function(prefs) {
    ExtractFrame.call(this, prefs);
    this._displayMode = prefs.security.display_decrypted;
    this._dDialog = null;
    // decrypt popup active
    this._dPopup = false;
    this._ctrlName = 'dFrame-' + this.id;
    this._typeRegex = /-----BEGIN PGP MESSAGE-----[\s\S]+?-----END PGP MESSAGE-----/;
  };

  decryptFrame.prototype = Object.create(ExtractFrame.prototype);
  decryptFrame.prototype.parent = ExtractFrame.prototype;

  decryptFrame.prototype._renderFrame = function() {
    this.parent._renderFrame.call(this);
    this._eFrame.addClass('m-decrypt');
  };

  decryptFrame.prototype._clickHandler = function() {
    this.parent._clickHandler.call(this);
    if (this._displayMode == mvelo.DISPLAY_INLINE) {
      this._inlineDialog();
    } else if (this._displayMode == mvelo.DISPLAY_POPUP) {
      this._popupDialog();
    }
    return false;
  };

  decryptFrame.prototype._inlineDialog = function() {
    this._dDialog = $('<iframe/>', {
      id: 'dDialog-' + this.id,
      'class': 'm-frame-dialog',
      frameBorder: 0,
      scrolling: 'no'
    });
    var url;
    if (mvelo.crx) {
      url = mvelo.extension.getURL('common/ui/inline/dialogs/decryptInline.html?id=' + this.id);
    } else if (mvelo.ffa) {
      url = 'about:blank?mvelo=decryptInline&id=' + this.id;
    }
    this._dDialog.attr('src', url);
    this._eFrame.append(this._dDialog);
    this._setFrameDim();
    this._dDialog.fadeIn();
  };

  decryptFrame.prototype._popupDialog = function() {
    this._port.postMessage({
      event: 'dframe-display-popup',
      sender: this._ctrlName
    });
    this._dPopup = true;
  };

  decryptFrame.prototype._removeDialog = function() {
    // check if dialog is active
    if (!this._dDialog && !this._dPopup) {
      return;
    }
    if (this._displayMode === mvelo.DISPLAY_INLINE) {
      this._dDialog.fadeOut();
      // removal triggers disconnect event
      this._dDialog.remove();
      this._dDialog = null;
    } else {
      this._dPopup = false;
    }
    this._eFrame.addClass('m-cursor');
    this._toggleIcon();
    this._eFrame.on('click', this._clickHandler.bind(this));
  };

  decryptFrame.prototype._registerEventListener = function() {
    this.parent._registerEventListener.call(this);
    var that = this;
    this._port.onMessage.addListener(function(msg) {
      //console.log('dFrame-%s event %s received', that.id, msg.event);
      switch (msg.event) {
        case 'remove-dialog':
        case 'dialog-cancel':
          that._removeDialog();
          break;
        case 'armored-message':
          that._port.postMessage({
            event: 'dframe-armored-message',
            data: that._getArmoredMessage(),
            sender: that._ctrlName
          });
          break;
      }
    });
  };

  return decryptFrame;

}());

/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var VerifyFrame = VerifyFrame || (function () {

  var verifyFrame = function (prefs) {
    ExtractFrame.call(this, prefs);
    this._displayMode = prefs.security.display_decrypted;
    this._vDialog = null;
    // verify popup active
    this._vPopup = false;
    this._ctrlName = 'vFrame-' + this.id;
    this._typeRegex = /-----BEGIN PGP SIGNED MESSAGE-----[\s\S]+?-----END PGP SIGNATURE-----/;
    this._pgpStartRegex = /BEGIN\sPGP\sSIGNED/;
    this._sigHeight = 128;
  };

  verifyFrame.prototype = Object.create(ExtractFrame.prototype);
  verifyFrame.prototype.parent = ExtractFrame.prototype;

  verifyFrame.prototype._init = function(pgpEnd) {
    this.parent._init.call(this, pgpEnd);
    this._calcSignatureHeight();
  };

  verifyFrame.prototype._renderFrame = function () {
    this.parent._renderFrame.call(this);
    this._eFrame.addClass('m-verify');
    this._eFrame.removeClass('m-large');
  };

  verifyFrame.prototype._calcSignatureHeight = function () {
    var msg = this._getArmoredMessage();
    msg = msg.split('\n');
    for (var i = 0; i < msg.length; i++) {
      if (/-----BEGIN\sPGP\sSIGNATURE-----/.test(msg[i])) {
        var height = this._pgpEnd.position().top + this._pgpEnd.height() - this._pgpElement.position().top - 2;
        this._sigHeight = parseInt(height / msg.length * (msg.length - i), 10);
        break;
      }
    }
  };

  verifyFrame.prototype._clickHandler = function () {
    this.parent._clickHandler.call(this);
    if (this._displayMode == mvelo.DISPLAY_INLINE) {
      this._inlineDialog();
    } else if (this._displayMode == mvelo.DISPLAY_POPUP) {
      this._popupDialog();
    }
    return false;
  };

  verifyFrame.prototype._inlineDialog = function () {
    this._vDialog = $('<iframe/>', {
      id: 'vDialog-' + this.id,
      'class': 'm-frame-dialog',
      frameBorder: 0,
      scrolling: 'no'
    });
    var url;
    if (mvelo.crx) {
      url = mvelo.extension.getURL('common/ui/inline/dialogs/verifyInline.html?id=' + this.id);
    } else if (mvelo.ffa) {
      url = 'about:blank?mvelo=verifyInline&id=' + this.id;
    }
    this._vDialog.attr('src', url);
    this._eFrame.append(this._vDialog);
    this._setFrameDim();
    this._vDialog.fadeIn();
  };

  verifyFrame.prototype._popupDialog = function () {
    this._port.postMessage({
      event: 'vframe-display-popup',
      sender: this._ctrlName
    });
    this._vPopup = true;
  };

  verifyFrame.prototype._removeDialog = function () {
    // check if dialog is active
    if (!this._vDialog && !this._vPopup) {
      return;
    }
    if (this._displayMode === mvelo.DISPLAY_INLINE) {
      this._vDialog.fadeOut();
      // removal triggers disconnect event
      this._vDialog.remove();
      this._vDialog = null;
    } else {
      this._vPopup = false;
    }
    this._eFrame.addClass('m-cursor');
    this._eFrame.removeClass('m-open');
    this._eFrame.on('click', this._clickHandler.bind(this));
  };

  verifyFrame.prototype._getArmoredMessage = function() {
    var msg;
    // selection method does not work in Firefox if pre element without linebreaks with <br>
    if (this._pgpElement.is('pre') && !this._pgpElement.find('br').length) {
      msg = this._pgpElement.text();
    } else {
      var sel = document.defaultView.getSelection();
      sel.selectAllChildren(this._pgpElement.get(0));
      msg = sel.toString();
      sel.removeAllRanges();
    }
    return msg;
  };

  verifyFrame.prototype._setFrameDim = function() {
    var pgpElementPos = this._pgpElement.position();
    this._eFrame.width(this._pgpElement.width() - 2);
    var height = this._pgpEnd.position().top + this._pgpEnd.height() - pgpElementPos.top - 2;
    var top = pgpElementPos.top + this._pgpElementAttr.marginTop + this._pgpElementAttr.paddingTop;
    if (this._vDialog) {
      this._eFrame.height(height);
      this._eFrame.css('top', top);
    } else {
      this._eFrame.height(this._sigHeight);
      this._eFrame.css('top', top + height - this._sigHeight);
    }
  },

  verifyFrame.prototype._registerEventListener = function () {
    this.parent._registerEventListener.call(this);
    var that = this;
    this._port.onMessage.addListener(function (msg) {
      //console.log('dFrame-%s event %s received', that.id, msg.event);
      switch (msg.event) {
        case 'remove-dialog':
          that._removeDialog();
          break;
        case 'armored-message':
          that._port.postMessage({
            event: 'vframe-armored-message',
            data: that._getArmoredMessage(),
            sender: that._ctrlName
          });
          break;
      }
    });
  };

  return verifyFrame;

}());

/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2013  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var ImportFrame = ImportFrame || (function() {

  var importFrame = function(prefs) {
    ExtractFrame.call(this, prefs);
    this._ctrlName = 'imFrame-' + this.id;
    this._typeRegex = /-----BEGIN PGP PUBLIC KEY BLOCK-----[\s\S]+?-----END PGP PUBLIC KEY BLOCK-----/;
  };

  importFrame.prototype = Object.create(ExtractFrame.prototype);
  importFrame.prototype.parent = ExtractFrame.prototype;

  importFrame.prototype._renderFrame = function() {
    this.parent._renderFrame.call(this);
    this._eFrame.addClass('m-import');
  };

  importFrame.prototype._clickHandler = function() {
    var that = this;
    this.parent._clickHandler.call(this, function() {
      that._port.postMessage({
        event: 'imframe-armored-key',
        data: that._getArmoredMessage(),
        sender: that._ctrlName
      });
    });
    return false;
  };

  importFrame.prototype._registerEventListener = function() {
    this.parent._registerEventListener.call(this);
    var that = this;
    this._port.onMessage.addListener(function(msg) {
      switch (msg.event) {
        case 'import-result':
          if (msg.resultType.error) {
            that._eFrame.addClass('m-error');
          } else if (msg.resultType.warning) {
            that._eFrame.addClass('m-warning');
          } else if (msg.resultType.success) {
            that._eFrame.addClass('m-ok');
          }
          break;
      }
    });
  };

  return importFrame;

}());


/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var EncryptFrame = EncryptFrame || (function() {

  var encryptFrame = function(prefs) {
    this.id = mvelo.getHash();
    this._editElement = null;
    this._eFrame = null;
    this._eDialog = null;
    this._port = null;
    this._isToolbar = false;
    this._refreshPosIntervalID = 0;
    this._emailTextElement = null;
    this._emailUndoText = null;
    this._editorMode = prefs.security.editor_mode;
    // type of external editor
    this._editorType = prefs.general.editor_type;
    this._options = {expanded: false, closeBtn: true};
    this._keyCounter = 0;
  };

  encryptFrame.prototype = {

    attachTo: function(element, options) {
      $.extend(this._options, options);
      this._init(element);
      this._renderFrame(this._options.expanded);
      this._establishConnection();
      this._registerEventListener();
      // set status to attached
      this._editElement.data(mvelo.FRAME_STATUS, mvelo.FRAME_ATTACHED);
      // store frame obj in element tag
      this._editElement.data(mvelo.FRAME_OBJ, this);
    },

    getID: function() {
      return this.id;
    },

    _init: function(element) {
      this._editElement = element;
      this._emailTextElement = this._options.editor || (this._editElement.is('iframe') ? this._editElement.contents().find('body') : this._editElement);
      // inject style if we have a non-body editable element inside a dynamic iframe
      if (!this._editElement.is('body') && this._editElement.closest('body').data(mvelo.DYN_IFRAME)) {
        var html = this._editElement.closest('html');
        if (!html.data('M-STYLE')) {
          var style = $('<link/>', {
            rel: 'stylesheet',
            href: mvelo.extension.getURL('common/ui/inline/framestyles.css')
          });
          // add style
          html.find('head').append(style);
          // set marker
          html.data('M-STYLE', true);
        }
      }
    },

    _renderFrame: function(expanded) {
      var that = this;
      // create frame
      var toolbar = '';
      if (this._options.closeBtn) {
        toolbar = toolbar + '<a class="m-frame-close">×</a>';
      } else {
        toolbar = toolbar + '<span class="m-frame-fill-right"></span>';
      }
      /* jshint multistr: true */
      toolbar = toolbar + '\
                <button id="signBtn" class="m-btn m-encrypt-button" type="button" ><i class="m-icon m-icon-sign"></i></button> \
                <button id="encryptBtn" class="m-btn m-encrypt-button" type="button"><i class="m-icon m-icon-encrypt"></i></button> \
                <button id="undoBtn" class="m-btn m-encrypt-button" type="button"><i class="m-icon m-icon-undo"></i></button> \
                <button id="editorBtn" class="m-btn m-encrypt-button" type="button"><i class="m-icon m-icon-editor"></i></button> \
                ';
      this._eFrame = $('<div/>', {
        id: 'eFrame-' + that.id,
        'class': 'm-encrypt-frame',
        html: toolbar
      });

      this._eFrame.insertAfter(this._editElement);
      $(window).on('resize', this._setFrameDim.bind(this));
      // to react on position changes of edit element, e.g. click on CC or BCC in GMail
      this._refreshPosIntervalID = window.setInterval(this._setFrameDim.bind(this), 1000);
      this._eFrame.find('.m-frame-close').on('click', this._closeFrame.bind(this));
      //this._eFrame.find('#signBtn').on('click', this._onSignButton.bind(this));
      this._eFrame.find('#encryptBtn').on('click', this._onEncryptButton.bind(this));
      this._eFrame.find('#undoBtn').on('click', this._onUndoButton.bind(this));
      this._eFrame.find('#editorBtn').on('click', this._onEditorButton.bind(this));
      if (!expanded) {
        this._isToolbar = true;
        this._normalizeButtons();
        this._eFrame.fadeIn('slow');
      } else {
        this.showEncryptDialog();
      }
      if (this._editorMode === mvelo.EDITOR_EXTERNAL) {
        this._emailTextElement.on('keypress', function() {
          if (++that._keyCounter >= 13) {
            that._emailTextElement.off('keypress');
            that._eFrame.fadeOut('slow', function() {
              that._closeFrame();
            });
          }
        });
      }
    },

    _normalizeButtons: function() {
      //console.log('editor mode', this._editorMode);
      this._eFrame.find('.m-encrypt-button').hide();
      switch (this._editorMode) {
        case mvelo.EDITOR_WEBMAIL:
          this._eFrame.find('#encryptBtn').show();
          //this._eFrame.find('#signBtn').show();
          break;
        case mvelo.EDITOR_EXTERNAL:
          this._eFrame.find('#editorBtn').show();
          break;
        case mvelo.EDITOR_BOTH:
          this._eFrame.find('#encryptBtn').show();
          this._eFrame.find('#editorBtn').show();
          break;
        default:
          throw 'Unknown editor mode';
      }
      if (this._emailUndoText) {
        this._eFrame.find('#undoBtn').show();
      }
      this._setFrameDim();
    },

    _onSignButton: function() {
      this.showSignDialog();
      return false;
    },

    _onEncryptButton: function() {
      this.showEncryptDialog();
      return false;
    },

    _onUndoButton: function() {
      this._resetEmailText();
      this._normalizeButtons();
      return false;
    },

    _onEditorButton: function() {
      this._emailTextElement.off('keypress');
      this._showMailEditor();
      return false;
    },

    showSignDialog: function() {
      this._expandFrame(this._showDialog.bind(this, 'sign'));
    },

    showEncryptDialog: function() {
      this._expandFrame(this._showDialog.bind(this, 'encrypt'));
    },

    _expandFrame: function(callback) {
      this._eFrame.hide();
      this._eFrame.find('.m-encrypt-button').hide();
      this._eFrame.addClass('m-encrypt-frame-expanded');
      this._eFrame.css('margin', this._editElement.css('margin'));
      this._isToolbar = false;
      this._setFrameDim();
      this._eFrame.fadeIn('slow', callback);
    },

    _closeFrame: function(finalClose) {
      this._eFrame.fadeOut(function() {
        window.clearInterval(this._refreshPosIntervalID);
        $(window).off('resize');
        this._eFrame.remove();
        if (finalClose === true) {
          this._port.disconnect();
          this._editElement.data(mvelo.FRAME_STATUS, null);
        } else {
          this._editElement.data(mvelo.FRAME_STATUS, mvelo.FRAME_DETACHED);
        }
        this._editElement.data(mvelo.FRAME_OBJ, null);
      }.bind(this));
      return false;
    },

    _setFrameDim: function() {
      var editElementPos = this._editElement.position();
      var editElementWidth = this._editElement.width();
      if (this._isToolbar) {
        var toolbarWidth = this._eFrame.width();
        this._eFrame.css('top', editElementPos.top + 3);
        this._eFrame.css('left', editElementPos.left + editElementWidth - toolbarWidth - 20);
      } else {
        this._eFrame.css('top', editElementPos.top + 2);
        this._eFrame.css('left', editElementPos.left + 2);
        this._eFrame.width(editElementWidth - 20);
        this._eFrame.height(this._editElement.height() - 4);
      }
    },

    _showDialog: function(type) {
      this._eDialog = $('<iframe/>', {
        id: 'eDialog-' + this.id,
        'class': 'm-frame-dialog',
        frameBorder: 0,
        scrolling: 'no'
      });
      var url, dialog;
      if (type === 'encrypt') {
        dialog = 'encryptDialog';
      } else if (type === 'sign') {
        dialog = 'signDialog';
      }
      if (mvelo.crx) {
        url = mvelo.extension.getURL('common/ui/inline/dialogs/' + dialog + '.html?id=' + this.id);
      } else if (mvelo.ffa) {
        url = 'about:blank?mvelo=' + dialog + '&id=' + this.id;
      }
      this._eDialog.attr('src', url);
      this._eFrame.append(this._eDialog);
      this._setFrameDim();
      this._eDialog.fadeIn();
    },

    _showMailEditor: function() {
      this._port.postMessage({
        event: 'eframe-display-editor',
        sender: 'eFrame-' + this.id,
        text: this._getEmailText(this._editorType == mvelo.PLAIN_TEXT ? 'text' : 'html')
      });
    },

    _establishConnection: function() {
      this._port = mvelo.extension.connect({name: 'eFrame-' + this.id});
    },

    _removeDialog: function() {
      if (!this._eDialog) return;
      this._eDialog.fadeOut();
      // removal triggers disconnect event
      this._eDialog.remove();
      this._eDialog = null;
      this._showToolbar();
    },

    _showToolbar: function() {
      this._eFrame.fadeOut(function() {
        this._eFrame.removeClass('m-encrypt-frame-expanded');
        this._eFrame.removeAttr('style');
        this._isToolbar = true;
        this._normalizeButtons();
        this._eFrame.fadeIn('slow');
      }.bind(this));
      return false;
    },

    _html2text: function(html) {
      html = $('<div/>').html(html);
      // replace anchors
      html = html.find('a').replaceWith(function() {
                                          return $(this).text() + ' (' + $(this).attr('href') + ')';
                                        })
                           .end()
                           .html();
      html = html.replace(/(<(br|ul|ol)>)/g, '\n'); // replace <br>,<ol>,<ul> with new line
      html = html.replace(/<\/(div|p|li)>/g, '\n'); // replace </div>, </p> or </li> tags with new line
      html = html.replace(/<li>/g, '- ');
      html = html.replace(/<(.+?)>/g, ''); // remove tags
      html = html.replace(/\n{3,}/g, '\n\n'); // compress new line
      return $('<div/>').html(html).text(); // decode
    },

    _getEmailText: function(type) {
      var text, html;
      if (this._emailTextElement.is('textarea')) {
        text = this._emailTextElement.val();
      } else { // html element
        if (type === 'text') {
          this._emailTextElement.focus();
          var element = this._emailTextElement.get(0);
          var sel = element.ownerDocument.defaultView.getSelection();
          sel.selectAllChildren(element);
          text = sel.toString();
          sel.removeAllRanges();
        } else {
          html = this._emailTextElement.html();
          html = html.replace(/\n/g, ''); // remove new lines
          text = html;
        }
      }
      return text;
    },

    /**
     * Save editor content for later undo
     */
    _saveEmailText: function() {
      if (this._emailTextElement.is('textarea')) {
        this._emailUndoText = this._emailTextElement.val();
      } else {
        this._emailUndoText = this._emailTextElement.html();
      }
    },

    _getEmailRecipient: function() {
      var raw_emails = [];
      var emailRegex = /[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/g;
      // Gmail
      $('form').find('span').filter(function(){
        return $(this).attr('email') != undefined;}).each(function() {
          var valid = $(this).attr('email').match(emailRegex);
          if (valid !== null) {
            raw_emails = raw_emails.concat(valid);
          }
      });

      var emails = [];
      $.each(raw_emails, function(i, el){
        if($.inArray(el, emails) === -1) emails.push(el);
      });
      console.log('found emails', emails);
      return emails;
    },

    /**
     * Replace content of editor element (_emailTextElement)
     * @param {string} msg txt or html content
     */
    _setMessage: function(msg, type) {
      if (this._emailTextElement.is('textarea')) {
        // decode HTML entities for type text due to previous HTML parsing
        msg = $('<div/>').html(msg).text(); // decode
        if (this._options.set_text) {
          this._options.set_text(msg);
        } else {
          this._emailTextElement.val(msg);
        }
      } else {
        // element is contenteditable or RTE
        if (type == 'text') {
          var wrapper = $('<div/>');
          wrapper.append($('<pre/>').html(msg));
          msg = wrapper.html();
        }
        if (this._options.set_text) {
          this._options.set_text(msg);
        } else {
          this._emailTextElement.html(msg);
        }
      }
    },

    _resetEmailText: function() {
      if (this._emailTextElement.is('textarea')) {
        this._emailTextElement.val(this._emailUndoText);
      } else {
        this._emailTextElement.html(this._emailUndoText);
      }
      this._emailUndoText = null;
    },

    _registerEventListener: function() {
      var that = this;
      this._port.onMessage.addListener(function(msg) {
        //console.log('eFrame-%s event %s received', that.id, msg.event);
        switch (msg.event) {
          case 'encrypt-dialog-cancel':
            that._removeDialog();
            break;
          case 'email-text':
            that._port.postMessage({
              event: 'eframe-email-text',
              data: that._getEmailText(msg.type),
              action: msg.action,
              sender: 'eFrame-' + that.id
            });
            break;
          case 'destroy':
            that._closeFrame(true);
            break;
          case 'recipient-proposal':
            that._port.postMessage({
              event: 'eframe-recipient-proposal',
              data: that._getEmailRecipient(),
              sender: 'eFrame-' + that.id
            });
            that._port.postMessage({
              event: 'eframe-textarea-element',
              data: that._emailTextElement.is('textarea'),
              sender: 'eFrame-' + that.id
            });
            break;
          case 'encrypted-message':
          case 'signed-message':
            that._saveEmailText();
            that._removeDialog();
            that._setMessage(msg.message, 'text');
            break;
          case 'set-editor-output':
            that._saveEmailText();
            that._normalizeButtons();
            that._setMessage(msg.text, that._editorType == mvelo.PLAIN_TEXT ? 'text' : 'html');
            break;
          case 'dialog-cancel':
            that._removeDialog();
            break;
          default:
            console.log('unknown event');
        }
      });
    }
  };

  encryptFrame.isAttached = function(element) {
    var status = element.data(mvelo.FRAME_STATUS);
    switch (status) {
      case mvelo.FRAME_ATTACHED:
      case mvelo.FRAME_DETACHED:
        return true;
      default:
        return false;
    }
  };

  return encryptFrame;

}());
//# sourceURL=cs-mailvelope.js